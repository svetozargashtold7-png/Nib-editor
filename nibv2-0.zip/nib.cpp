// nib — быстрый и простой терминальный редактор для кода.
// C++17, без зависимостей. Linux / macOS / Termux / Windows (Windows Terminal).
#include <algorithm>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <functional>
#include <iterator>
#include <map>
#include <memory>
#include <string>
#include <unordered_set>
#include <vector>

#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
#else
#include <sys/ioctl.h>
#include <sys/select.h>
#include <termios.h>
#include <unistd.h>
#endif

using std::string;
using std::vector;

static int TAB = 4;

// ───────────────────────── терминал ─────────────────────────
struct Term {
#ifdef _WIN32
    HANDLE hin{}, hout{};
    DWORD oin{}, oout{};
    UINT ocp{}, oocp{};
#else
    termios orig{};
#endif
    unsigned char buf[4096];
    int bl = 0, bp = 0;

    void write(const string& s) {
#ifdef _WIN32
        DWORD n;
        WriteFile(hout, s.data(), (DWORD)s.size(), &n, nullptr);
#else
        size_t off = 0;
        while (off < s.size()) {
            ssize_t n = ::write(1, s.data() + off, s.size() - off);
            if (n <= 0) break;
            off += (size_t)n;
        }
#endif
    }
    void enter(bool mouse = true) {
#ifdef _WIN32
        hin = GetStdHandle(STD_INPUT_HANDLE);
        hout = GetStdHandle(STD_OUTPUT_HANDLE);
        GetConsoleMode(hin, &oin);
        GetConsoleMode(hout, &oout);
        ocp = GetConsoleCP();
        oocp = GetConsoleOutputCP();
        SetConsoleMode(hin, (oin & ~(ENABLE_ECHO_INPUT | ENABLE_LINE_INPUT | ENABLE_PROCESSED_INPUT |
                                     ENABLE_QUICK_EDIT_MODE)) |
                                ENABLE_VIRTUAL_TERMINAL_INPUT | ENABLE_EXTENDED_FLAGS);
        SetConsoleMode(hout, oout | ENABLE_PROCESSED_OUTPUT | ENABLE_VIRTUAL_TERMINAL_PROCESSING);
        SetConsoleCP(CP_UTF8);
        SetConsoleOutputCP(CP_UTF8);
#else
        tcgetattr(0, &orig);
        termios r = orig;
        r.c_iflag &= ~(BRKINT | ICRNL | INPCK | ISTRIP | IXON);
        r.c_oflag &= ~(OPOST);
        r.c_cflag |= CS8;
        r.c_lflag &= ~(ECHO | ICANON | IEXTEN | ISIG);
        tcsetattr(0, TCSAFLUSH, &r);
#endif
        write(string("\x1b[?1049h") + (mouse ? "\x1b[?1000h\x1b[?1002h\x1b[?1006h" : "") + "\x1b[?2004h");
    }
    void leave() {
        write("\x1b[?2004l\x1b[?1006l\x1b[?1002l\x1b[?1000l\x1b[0m\x1b[?25h\x1b[?1049l");
#ifdef _WIN32
        SetConsoleMode(hin, oin);
        SetConsoleMode(hout, oout);
        SetConsoleCP(ocp);
        SetConsoleOutputCP(oocp);
#else
        tcsetattr(0, TCSAFLUSH, &orig);
#endif
    }
    void size(int& r, int& c) {
        r = 24;
        c = 80;
#ifdef _WIN32
        CONSOLE_SCREEN_BUFFER_INFO i;
        if (GetConsoleScreenBufferInfo(hout, &i)) {
            r = i.srWindow.Bottom - i.srWindow.Top + 1;
            c = i.srWindow.Right - i.srWindow.Left + 1;
        }
#else
        winsize w;
        if (ioctl(1, TIOCGWINSZ, &w) == 0 && w.ws_col > 0) {
            r = w.ws_row;
            c = w.ws_col;
        }
#endif
    }
    int readByte(int ms) {
        if (bp < bl) return buf[bp++];
#ifdef _WIN32
        if (WaitForSingleObject(hin, ms) != WAIT_OBJECT_0) return -1;
        DWORD n = 0;
        if (!ReadFile(hin, buf, sizeof buf, &n, nullptr) || n == 0) return -1;
        bl = (int)n;
#else
        fd_set fs;
        FD_ZERO(&fs);
        FD_SET(0, &fs);
        timeval tv{ms / 1000, (ms % 1000) * 1000};
        if (select(1, &fs, nullptr, nullptr, &tv) <= 0) return -1;
        ssize_t n = ::read(0, buf, sizeof buf);
        if (n <= 0) return -1;
        bl = (int)n;
#endif
        bp = 0;
        return buf[bp++];
    }
};

// ───────────────────────── ввод ─────────────────────────
enum {
    K_NONE = -1, K_CHAR = 0, K_TAB = 9, K_ENTER = 13, K_ESC = 27, K_BS = 127,
    K_UP = 1000, K_DOWN, K_LEFT, K_RIGHT, K_HOME, K_END, K_PGUP, K_PGDN, K_DEL, K_MOUSE, K_PASTE, K_F1 = 1100
};
struct Key {
    int c = K_NONE;
    string text;
    bool shift = false, ctrl = false, alt = false, release = false;
    int mx = 0, my = 0, mb = 0;
};

// ───────────────────────── utf-8 ─────────────────────────
static inline bool cont(unsigned char c) { return (c & 0xC0) == 0x80; }
static int nextx(const string& s, int x) {
    if (x >= (int)s.size()) return x;
    x++;
    while (x < (int)s.size() && cont(s[x])) x++;
    return x;
}
static int prevx(const string& s, int x) {
    if (x <= 0) return 0;
    x--;
    while (x > 0 && cont(s[x])) x--;
    return x;
}
static int dcol(const string& s, int x) {
    int col = 0;
    for (int i = 0; i < x && i < (int)s.size(); i++) {
        if (s[i] == '\t') col += TAB - col % TAB;
        else if (!cont(s[i])) col++;
    }
    return col;
}
static int col2x(const string& s, int target) {
    int col = 0, i = 0;
    while (i < (int)s.size()) {
        int w = s[i] == '\t' ? TAB - col % TAB : 1;
        if (col + w > target && !(w > 1 && target - col >= w / 2 + 1)) break;
        if (col >= target) break;
        col += w;
        i = nextx(s, i);
    }
    return i;
}
static int ulen(const string& s) {
    int n = 0;
    for (unsigned char c : s) if (!cont(c)) n++;
    return n;
}
static string ucut(const string& s, int n) {
    int i = 0, k = 0;
    while (i < (int)s.size() && k < n) { i = nextx(s, i); k++; }
    return s.substr(0, i);
}
static bool isident(unsigned char c) { return isalnum(c) || c == '_' || c >= 128; }

// ───────────────────────── буфер ─────────────────────────
struct Pos {
    int y = 0, x = 0;
};
static bool operator<(Pos a, Pos b) { return a.y < b.y || (a.y == b.y && a.x < b.x); }
static bool operator==(Pos a, Pos b) { return a.y == b.y && a.x == b.x; }

struct Edit {
    Pos at, cb, ca;
    string removed, inserted;
    int g = 0;
};

enum { H_NORM, H_KW, H_STR, H_COM, H_NUM, H_FN };

static string b64(const string& in) {
    static const char* t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    string o;
    size_t i = 0;
    for (; i + 2 < in.size(); i += 3) {
        unsigned v = ((unsigned char)in[i] << 16) | ((unsigned char)in[i + 1] << 8) | (unsigned char)in[i + 2];
        o += t[v >> 18]; o += t[(v >> 12) & 63]; o += t[(v >> 6) & 63]; o += t[v & 63];
    }
    if (i + 1 == in.size()) {
        unsigned v = (unsigned char)in[i] << 16;
        o += t[v >> 18]; o += t[(v >> 12) & 63]; o += "==";
    } else if (i + 2 == in.size()) {
        unsigned v = ((unsigned char)in[i] << 16) | ((unsigned char)in[i + 1] << 8);
        o += t[v >> 18]; o += t[(v >> 12) & 63]; o += t[(v >> 6) & 63]; o += '=';
    }
    return o;
}

struct Doc {  // документ (буфер): общий для всех панелей, которые его показывают
    vector<string> L{""};
    string path, langName = "text";
    bool dirty = false, crlf = false, finalNL = true;
    vector<Edit> undo, redo;
    int nextG = 1, grp = 0;
    bool inGrp = false, noMerge = true;
    std::unordered_set<string> kws;
    string lineComment, blockOpen, blockClose;
    bool hlOn = false, backtick = false, triple = false;
    vector<unsigned char> lstate{0};  // состояние подсветки в начале строки (кэш)
    int validUpTo = 0;
};
struct View { Pos cur, anc; bool sel = false; int want = 0, rowoff = 0, coloff = 0; };
struct Pane { std::shared_ptr<Doc> doc; View v; };
struct Tab { vector<Pane> panes; int active = 0; bool vsplit = true; };
struct Rect { int x = 0, y = 0, w = 0, h = 0; };
struct Config {
    int tab = 4;
    bool expandTab = true, lineNumbers = true, autoPair = true, autoIndent = true, highlight = true, mouse = true;
    string theme = "dark";
    std::map<string, int> colors;
    std::map<string, string> binds;
};

struct Editor {
    Term& t;
    Doc* d = nullptr;  // документ активной панели
    bool quit = false, quitArm = false, closeArm = false;
    Pos cur, anc;
    bool sel = false;
    int want = 0, rowoff = 0, coloff = 0, rows = 0, cols = 0;
    int px = 0, py = 0, pw = 80, ph = 24, gut = 4, textRows = 20, textw = 70;
    string clip;
    bool clipLine = false;
    string msg, lastQ;
    std::chrono::steady_clock::time_point msgUntil;
    bool promptOn = false;
    string promptLabel, promptText;
    vector<string> prev;
    bool dragging = false;
    Pos mA{-1, -1}, mB{-1, -1};  // парные скобки

    // ═══════════ конфиг, вкладки, панели, палитра ═══════════
    Config cfg;
    bool live = false;
    std::map<string, string> binds;
    std::map<string, std::function<void()>> actions;
    vector<std::pair<string, string>> actionList;
    vector<Tab> tabs;
    int ti = 0;
    vector<Rect> rects;
    vector<std::pair<int, int>> tabSpans;
    vector<int> tabSpanIdx;
    string hcol[6], gutStr, gutCurStr, selStr, matchStr, stActive, stInactive, cfgError;
    vector<string> fileCache;
    std::chrono::steady_clock::time_point fileCacheT;
    bool fileCacheOk = false;

    explicit Editor(Term& tt) : t(tt) {
        Tab tb;
        Pane pn;
        pn.doc = std::make_shared<Doc>();
        tb.panes.push_back(pn);
        tabs.push_back(tb);
        d = tabs[0].panes[0].doc.get();
        registerActions();
        loadConfig();
    }

    // ── утилиты ──
    static string trim(const string& x) {
        size_t a = x.find_first_not_of(" \t\r"), b = x.find_last_not_of(" \t\r");
        return a == string::npos ? string() : x.substr(a, b - a + 1);
    }
    static string baseName(const string& x) {
        size_t i = x.find_last_of("/\\");
        return i == string::npos ? x : x.substr(i + 1);
    }
    static bool sameFile(const string& a, const string& b) {
        if (a.empty() || b.empty()) return false;
        if (a == b) return true;
        std::error_code ec;
        bool r = std::filesystem::equivalent(a, b, ec);
        return !ec && r;
    }
    string indentUnit() const { return cfg.expandTab ? string(TAB, ' ') : string("\t"); }
    static string cfgPath() {
        const char* x = getenv("NIB_CONFIG");
        if (x && *x) return x;
#ifdef _WIN32
        const char* a = getenv("APPDATA");
        return string(a ? a : ".") + "\\nib\\config";
#else
        const char* xd = getenv("XDG_CONFIG_HOME");
        if (xd && *xd) return string(xd) + "/nib/config";
        const char* h = getenv("HOME");
        return string(h ? h : ".") + "/.config/nib/config";
#endif
    }

    // ── конфиг ──
    static bool parseBool(const string& v, bool& out) {
        string x = lower(v);
        if (x == "true" || x == "yes" || x == "on" || x == "1") { out = true; return true; }
        if (x == "false" || x == "no" || x == "off" || x == "0") { out = false; return true; }
        return false;
    }
    static string normSpec(const string& spec) {
        bool c = false, a = false, sh = false;
        string sp = lower(spec), key;
        size_t st0 = 0;
        while (true) {
            size_t e = sp.find('+', st0);
            string part = trim(sp.substr(st0, e == string::npos ? string::npos : e - st0));
            if (e == string::npos) { key = part; break; }
            if (part == "ctrl" || part == "control") c = true;
            else if (part == "alt" || part == "meta") a = true;
            else if (part == "shift") sh = true;
            else return "";
            st0 = e + 1;
        }
        if (key.empty()) return "";
        if (key == "backspace") key = "bs";
        else if (key == "delete") key = "del";
        else if (key == "pageup") key = "pgup";
        else if (key == "pagedown") key = "pgdn";
        else if (key == "return") key = "enter";
        else if (key == "escape") key = "esc";
        return string(c ? "ctrl+" : "") + (a ? "alt+" : "") + (sh ? "shift+" : "") + key;
    }
    static std::map<string, int> themeDefaults(const string& th) {
        if (th == "light")
            return {{"keyword", 125}, {"string", 28}, {"comment", 245}, {"number", 130}, {"function", 25},
                    {"gutter", 247}, {"gutter_cur", 16}, {"selection", 153}, {"match", 186}, {"status_fg", 231},
                    {"status_bg", 24}, {"status_inactive_fg", 236}, {"status_inactive_bg", 252}};
        return {{"keyword", 176}, {"string", 114}, {"comment", 244}, {"number", 215}, {"function", 111},
                {"gutter", 240}, {"gutter_cur", 255}, {"selection", 24}, {"match", 240}, {"status_fg", 231},
                {"status_bg", 60}, {"status_inactive_fg", 248}, {"status_inactive_bg", 236}};
    }
    static std::map<string, string> defaultBinds() {
        std::map<string, string> m = {
            {"ctrl+q", "quit"}, {"ctrl+s", "save"}, {"ctrl+z", "undo"}, {"ctrl+y", "redo"}, {"ctrl+c", "copy"},
            {"ctrl+x", "cut"}, {"ctrl+v", "paste"}, {"ctrl+a", "select_all"}, {"ctrl+f", "find"},
            {"ctrl+n", "find_next"}, {"ctrl+b", "find_prev"}, {"f3", "find_next"}, {"shift+f3", "find_prev"},
            {"ctrl+g", "goto_line"}, {"ctrl+d", "duplicate_line"}, {"ctrl+k", "delete_line"}, {"ctrl+r", "replace"},
            {"ctrl+e", "grep"}, {"alt+f", "grep"}, {"ctrl+o", "open"}, {"ctrl+p", "quick_open"}, {"f1", "palette"},
            {"alt+p", "palette"}, {"ctrl+slash", "toggle_comment"}, {"ctrl+t", "new_tab"}, {"ctrl+w", "close"},
            {"ctrl+backslash", "split_v"}, {"ctrl+rbracket", "split_h"}, {"f6", "next_pane"}, {"alt+w", "next_pane"},
            {"ctrl+pgdn", "next_tab"}, {"ctrl+pgup", "prev_tab"}, {"alt+right", "next_tab"}, {"alt+left", "prev_tab"},
            {"alt+up", "move_up"}, {"alt+down", "move_down"}, {"alt+bs", "delete_word"}};
        for (int i = 1; i <= 9; i++) m["alt+" + std::to_string(i)] = "tab" + std::to_string(i);
        return m;
    }
    string defaultConfigText() {
        string x = R"(# nib — конфиг. Строки вида  ключ = значение.  Всё после # — комментарий.
# После сохранения этого файла в nib настройки применяются сразу.

tab_size = 4            # ширина отступа (1-16)
expand_tab = true       # true — пробелы вместо табов
line_numbers = true
auto_pair = true        # автозакрытие скобок и кавычек
auto_indent = true
highlight = true        # подсветка синтаксиса
mouse = true
theme = dark            # dark или light

# Цвета (0-255, палитра xterm-256). Ключи: keyword string comment number function
# gutter gutter_cur selection match status_fg status_bg status_inactive_fg status_inactive_bg
# color.keyword = 176

# Свои горячие клавиши:  bind.<клавиши> = <действие>   (none — отключить)
# Клавиши: ctrl+ alt+ shift+ и имя: a-z 0-9 up down left right home end pgup pgdn del tab enter bs esc
#          f1-f12 slash backslash rbracket
# bind.ctrl+d = duplicate_line
# bind.ctrl+q = none
#
# Доступные действия:
)";
        for (auto& a : actionList)
            if (!a.second.empty()) x += "#   " + a.first + " — " + a.second + "\n";
        return x;
    }
    void loadConfig() {
        cfgError.clear();
        Config c;
        std::ifstream f(cfgPath());
        if (f) {
            string line;
            int n = 0;
            auto err = [&](const string& m) { if (cfgError.empty()) cfgError = "config:" + std::to_string(n) + ": " + m; };
            auto names = themeDefaults("dark");
            while (std::getline(f, line)) {
                n++;
                size_t h = line.find('#');
                if (h != string::npos) line.resize(h);
                line = trim(line);
                if (line.empty()) continue;
                size_t eq = line.find('=');
                if (eq == string::npos) { err("ожидается ключ = значение"); continue; }
                string k = trim(line.substr(0, eq)), v = trim(line.substr(eq + 1)), kl = lower(k);
                bool b = false;
                if (kl == "tab_size") {
                    int x = atoi(v.c_str());
                    if (x < 1 || x > 16) err("tab_size должен быть 1-16"); else c.tab = x;
                } else if (kl == "expand_tab" || kl == "line_numbers" || kl == "auto_pair" || kl == "auto_indent" ||
                           kl == "highlight" || kl == "mouse") {
                    if (!parseBool(v, b)) { err("ожидается true или false"); continue; }
                    if (kl == "expand_tab") c.expandTab = b;
                    else if (kl == "line_numbers") c.lineNumbers = b;
                    else if (kl == "auto_pair") c.autoPair = b;
                    else if (kl == "auto_indent") c.autoIndent = b;
                    else if (kl == "highlight") c.highlight = b;
                    else c.mouse = b;
                } else if (kl == "theme") {
                    if (v == "dark" || v == "light") c.theme = v; else err("theme: dark или light");
                } else if (kl.rfind("color.", 0) == 0) {
                    string nm = kl.substr(6);
                    int x = atoi(v.c_str());
                    if (!names.count(nm)) err("неизвестный цвет " + nm);
                    else if (x < 0 || x > 255 || v.empty()) err("цвет должен быть 0-255");
                    else c.colors[nm] = x;
                } else if (kl.rfind("bind.", 0) == 0) {
                    string sp = normSpec(k.substr(5));
                    if (sp.empty() || v.empty()) err("неверная привязка клавиши");
                    else if (v != "none" && !actions.count(v)) err("неизвестное действие " + v);
                    else c.binds[sp] = v;
                } else err("неизвестный параметр " + k);
            }
        }
        cfg = c;
        applyConfig();
        if (!cfgError.empty()) setMsg(cfgError);
    }
    void applyConfig() {
        TAB = cfg.tab;
        auto col = themeDefaults(cfg.theme);
        for (auto& kv : cfg.colors) col[kv.first] = kv.second;
        auto fg = [&](const char* nm) { return "\x1b[38;5;" + std::to_string(col[nm]) + "m"; };
        auto bg = [&](const char* nm) { return "\x1b[48;5;" + std::to_string(col[nm]) + "m"; };
        hcol[0] = "";
        hcol[1] = fg("keyword"); hcol[2] = fg("string"); hcol[3] = fg("comment");
        hcol[4] = fg("number"); hcol[5] = fg("function");
        gutStr = fg("gutter");
        gutCurStr = "\x1b[1m" + fg("gutter_cur");
        selStr = bg("selection");
        matchStr = bg("match") + "\x1b[1m";
        stActive = fg("status_fg") + bg("status_bg");
        stInactive = fg("status_inactive_fg") + bg("status_inactive_bg");
        binds = defaultBinds();
        for (auto& kv : cfg.binds) binds[kv.first] = kv.second;
        Doc* save = d;
        for (auto& tb : tabs)
            for (auto& pn : tb.panes) { d = pn.doc.get(); detectLang(); }
        d = save;
        prev.clear();
        applyMouse();
    }
    void applyMouse() {
        if (!live) return;
        t.write(cfg.mouse ? "\x1b[?1000h\x1b[?1002h\x1b[?1006h" : "\x1b[?1006l\x1b[?1002l\x1b[?1000l");
    }
    void openConfig() {
        string cp = cfgPath();
        std::error_code ec;
        if (!std::filesystem::exists(cp, ec)) {
            std::filesystem::create_directories(std::filesystem::path(cp).parent_path(), ec);
            std::ofstream f(cp);
            f << defaultConfigText();
        }
        openInTab(cp);
    }

    // ── действия ──
    void act(const char* id, const char* title, std::function<void()> fn) {
        actions[id] = std::move(fn);
        actionList.push_back({id, title});
    }
    void runAction(const string& id) {
        if (id.empty() || id == "none") return;
        auto it = actions.find(id);
        if (it == actions.end()) { setMsg("Неизвестное действие: " + id); return; }
        it->second();
    }
    void registerActions() {
        act("save", "Сохранить", [this] { save(); });
        act("save_as", "Сохранить как…", [this] {
            string x;
            if (!prompt("Сохранить как: ", x) || x.empty()) return;
            d->path = x;
            detectLang();
            save();
        });
        act("save_all", "Сохранить все файлы", [this] { saveAll(); });
        act("quit", "Выйти", [this] {
            if (anyDirty() && !quitArm) { quitArm = true; setMsg("Есть несохранённые изменения! Ещё раз — выйти без сохранения"); }
            else quit = true;
        });
        act("undo", "Отменить", [this] { doUndo(); });
        act("redo", "Повторить", [this] { doRedo(); });
        act("copy", "Копировать", [this] { copy(false); });
        act("cut", "Вырезать", [this] { copy(true); });
        act("paste", "Вставить", [this] { paste(); });
        act("select_all", "Выделить всё", [this] { sel = true; anc = {0, 0}; cur = {(int)d->L.size() - 1, (int)d->L.back().size()}; });
        act("find", "Найти", [this] { find(); });
        act("find_next", "Найти дальше", [this] { findNext(true); });
        act("find_prev", "Найти назад", [this] { findNext(false); });
        act("replace", "Заменить", [this] { replaceFlow(); });
        act("grep", "Поиск по файлам проекта", [this] { grepFiles(); });
        act("goto_line", "Перейти к строке", [this] { gotoLine(); });
        act("duplicate_line", "Дублировать строку", [this] { duplicateLines(); });
        act("delete_line", "Удалить строку", [this] { deleteLines(); });
        act("move_up", "Переместить строку вверх", [this] { moveLines(-1); });
        act("move_down", "Переместить строку вниз", [this] { moveLines(1); });
        act("toggle_comment", "Закомментировать / раскомментировать", [this] { toggleComment(); });
        act("delete_word", "Удалить слово слева", [this] {
            if (deleteSel()) return;
            Pos e = cur;
            wordLeft(false);
            edit(cur, e, "");
        });
        act("open", "Открыть файл в этой панели…", [this] { openPrompt(); });
        act("quick_open", "Быстрое открытие файла", [this] { quickOpen(""); });
        act("palette", "Палитра команд", [this] { quickOpen(">"); });
        act("new_tab", "Новая вкладка", [this] { newTab(); });
        act("close", "Закрыть панель (или вкладку)", [this] { closePane(); });
        act("close_tab", "Закрыть вкладку целиком", [this] { closeTab(); });
        act("split_v", "Разделить вертикально (бок о бок)", [this] { splitPane(true); });
        act("split_h", "Разделить горизонтально (друг под другом)", [this] { splitPane(false); });
        act("next_pane", "Следующая панель", [this] {
            int n = (int)tabs[ti].panes.size();
            if (n > 1) activate(ti, (tabs[ti].active + 1) % n);
        });
        act("next_tab", "Следующая вкладка", [this] { goTab(ti + 1); });
        act("prev_tab", "Предыдущая вкладка", [this] { goTab(ti - 1); });
        for (int i = 1; i <= 9; i++)
            act(("tab" + std::to_string(i)).c_str(), "", [this, i] { if (i - 1 < (int)tabs.size()) goTab(i - 1); });
        act("toggle_numbers", "Номера строк: вкл/выкл", [this] { cfg.lineNumbers = !cfg.lineNumbers; prev.clear(); });
        act("toggle_theme", "Тема: тёмная/светлая", [this] { cfg.theme = cfg.theme == "dark" ? "light" : "dark"; applyConfig(); });
        act("toggle_expand_tab", "Отступ: пробелы/табы", [this] {
            cfg.expandTab = !cfg.expandTab;
            setMsg(cfg.expandTab ? "Отступ: пробелы" : "Отступ: табы");
        });
        act("open_config", "Открыть конфиг", [this] { openConfig(); });
        act("reload_config", "Перезагрузить конфиг", [this] { loadConfig(); if (cfgError.empty()) setMsg("Конфиг перезагружен"); });
    }

    // ── вкладки и панели ──
    Pane& ap() { return tabs[ti].panes[tabs[ti].active]; }
    View liveView() const {
        View v;
        v.cur = cur; v.anc = anc; v.sel = sel; v.want = want; v.rowoff = rowoff; v.coloff = coloff;
        return v;
    }
    void setLive(const View& v, Doc* dd) {
        d = dd;
        cur = v.cur; anc = v.anc; sel = v.sel; want = v.want; rowoff = v.rowoff; coloff = v.coloff;
        int n = (int)d->L.size();
        cur.y = std::max(0, std::min(cur.y, n - 1));
        cur.x = std::max(0, std::min(cur.x, (int)d->L[cur.y].size()));
        anc.y = std::max(0, std::min(anc.y, n - 1));
        anc.x = std::max(0, std::min(anc.x, (int)d->L[anc.y].size()));
        rowoff = std::max(0, std::min(rowoff, n - 1));
    }
    void syncOut() { ap().v = liveView(); }
    void activate(int nt, int np) {
        syncOut();
        ti = nt;
        tabs[ti].active = np;
        Pane& q = ap();
        setLive(q.v, q.doc.get());
        dragging = false;
    }
    void goTab(int i) {
        int n = (int)tabs.size();
        i = ((i % n) + n) % n;
        activate(i, tabs[i].active);
    }
    int docRefs(Doc* x) {
        int n = 0;
        for (auto& tb : tabs) for (auto& pn : tb.panes) if (pn.doc.get() == x) n++;
        return n;
    }
    bool anyDirty() {
        for (auto& tb : tabs) for (auto& pn : tb.panes) if (pn.doc->dirty) return true;
        return false;
    }
    std::shared_ptr<Doc> findDoc(const string& fp) {
        for (auto& tb : tabs) for (auto& pn : tb.panes) if (sameFile(pn.doc->path, fp)) return pn.doc;
        return nullptr;
    }
    std::shared_ptr<Doc> makeDoc(const string& fp) {
        auto nd = std::make_shared<Doc>();
        Doc* sv = d;
        d = nd.get();
        load(fp);
        d = sv;
        return nd;
    }
    void newTab(std::shared_ptr<Doc> doc = nullptr) {
        if (!doc) {
            doc = std::make_shared<Doc>();
            Doc* sv = d;
            d = doc.get();
            detectLang();
            d = sv;
        }
        syncOut();
        Tab tb;
        Pane pn;
        pn.doc = doc;
        tb.panes.push_back(pn);
        tabs.push_back(tb);
        ti = (int)tabs.size() - 1;
        Pane& q = ap();
        setLive(q.v, q.doc.get());
    }
    bool pristine() {
        return d->path.empty() && !d->dirty && d->L.size() == 1 && d->L[0].empty() && docRefs(d) == 1;
    }
    void openInTab(const string& fp) {
        for (int i = 0; i < (int)tabs.size(); i++)
            for (int j = 0; j < (int)tabs[i].panes.size(); j++)
                if (sameFile(tabs[i].panes[j].doc->path, fp)) { activate(i, j); return; }
        auto nd = makeDoc(fp);
        if (tabs[ti].panes.size() == 1 && pristine()) {
            syncOut();
            ap().doc = nd;
            ap().v = View();
            setLive(ap().v, nd.get());
        } else newTab(nd);
    }
    void openHere(const string& fp) {
        auto ex = findDoc(fp);
        if (d->dirty && docRefs(d) == 1 && ex.get() != d) { setMsg("Сначала сохраните изменения (Ctrl+S)"); return; }
        if (!ex) ex = makeDoc(fp);
        syncOut();
        ap().doc = ex;
        ap().v = View();
        setLive(ap().v, ex.get());
    }
    void splitPane(bool vertical) {
        Tab& tb = tabs[ti];
        int n = (int)tb.panes.size() + 1;
        int contentH = rows - (tabs.size() > 1 ? 1 : 0) - 1;
        if (n > 4) { setMsg("Максимум 4 панели во вкладке"); return; }
        if (vertical && (cols - (n - 1)) / n < 20) { setMsg("Мало места для вертикального разделения"); return; }
        if (!vertical && contentH / n < 5) { setMsg("Мало места для горизонтального разделения"); return; }
        syncOut();
        tb.vsplit = vertical;
        Pane np = ap();
        tb.panes.insert(tb.panes.begin() + tb.active + 1, np);
        tb.active++;
        Pane& q = ap();
        setLive(q.v, q.doc.get());
    }
    void closePane() {
        auto keep = ap().doc;
        if (d->dirty && docRefs(d) == 1 && !closeArm) {
            closeArm = true;
            setMsg("Несохранённые изменения! Ещё раз — закрыть без сохранения");
            return;
        }
        closeArm = false;
        Tab& tb = tabs[ti];
        tb.panes.erase(tb.panes.begin() + tb.active);
        if (tb.panes.empty()) {
            tabs.erase(tabs.begin() + ti);
            if (tabs.empty()) { quit = true; return; }
            ti = std::min(ti, (int)tabs.size() - 1);
        } else tb.active = std::min(tb.active, (int)tb.panes.size() - 1);
        Pane& q = ap();
        setLive(q.v, q.doc.get());
    }
    void closeTab() {
        auto keep = ap().doc;
        Tab& tb = tabs[ti];
        bool risk = false;
        for (auto& pn : tb.panes) {
            int inTab = 0;
            for (auto& q : tb.panes) if (q.doc == pn.doc) inTab++;
            if (pn.doc->dirty && docRefs(pn.doc.get()) == inTab) risk = true;
        }
        if (risk && !closeArm) {
            closeArm = true;
            setMsg("Несохранённые изменения! Ещё раз — закрыть вкладку без сохранения");
            return;
        }
        closeArm = false;
        tabs.erase(tabs.begin() + ti);
        if (tabs.empty()) { quit = true; return; }
        ti = std::min(ti, (int)tabs.size() - 1);
        Pane& q = ap();
        setLive(q.v, q.doc.get());
    }
    void saveAll() {
        int n = 0;
        vector<Doc*> seen;
        Doc* sv = d;
        for (auto& tb : tabs)
            for (auto& pn : tb.panes) {
                Doc* x = pn.doc.get();
                if (std::find(seen.begin(), seen.end(), x) != seen.end()) continue;
                seen.push_back(x);
                if (x->dirty && !x->path.empty()) { d = x; if (save()) n++; }
            }
        d = sv;
        setMsg("Сохранено файлов: " + std::to_string(n));
    }

    // ── быстрое открытие и палитра ──
    const vector<string>& projectFiles() {
        namespace fs = std::filesystem;
        auto now = std::chrono::steady_clock::now();
        if (fileCacheOk && now - fileCacheT < std::chrono::seconds(5)) return fileCache;
        fileCache.clear();
        static const char* skip[] = {"node_modules", "build", "target", "dist", "__pycache__", "venv"};
        static const char* binExt[] = {".png", ".jpg", ".jpeg", ".gif", ".ico", ".pdf", ".zip", ".gz", ".tar", ".o", ".a",
                                       ".so", ".dll", ".exe", ".class", ".jar", ".bin", ".dat", ".mp3", ".mp4", ".woff",
                                       ".woff2", ".ttf", ".pyc"};
        try {
            for (auto it = fs::recursive_directory_iterator(".", fs::directory_options::skip_permission_denied);
                 it != fs::recursive_directory_iterator() && fileCache.size() < 50000; ++it) {
                string name = it->path().filename().string();
                if (it->is_directory()) {
                    bool sk = name.size() > 1 && name[0] == '.';
                    for (auto s2 : skip) if (name == s2) sk = true;
                    if (sk) it.disable_recursion_pending();
                    continue;
                }
                if (!it->is_regular_file()) continue;
                string ext = lower(it->path().extension().string());
                bool bin = false;
                for (auto e : binExt) if (ext == e) bin = true;
                if (bin) continue;
                string rel = it->path().generic_string();
                if (rel.compare(0, 2, "./") == 0) rel = rel.substr(2);
                fileCache.push_back(rel);
            }
        } catch (...) {}
        std::sort(fileCache.begin(), fileCache.end());
        fileCacheOk = true;
        fileCacheT = now;
        return fileCache;
    }
    static bool fuzzy(const string& q, const string& s, int& score) {
        size_t qi = 0;
        int sc = 0, last = -2;
        size_t base = s.find_last_of("/\\");
        base = base == string::npos ? 0 : base + 1;
        for (size_t i = 0; i < s.size() && qi < q.size(); i++) {
            if (tolower((unsigned char)s[i]) == tolower((unsigned char)q[qi])) {
                sc += 2;
                if ((int)i == last + 1) sc += 6;
                if (i == 0 || strchr("/\\_-. ", s[i - 1])) sc += 8;
                if (i >= base) sc += 3;
                last = (int)i;
                qi++;
            }
        }
        if (qi < q.size()) return false;
        if (lower(s.substr(base)).find(lower(q)) != string::npos) sc += 40;
        score = sc * 8 - (int)s.size();
        return true;
    }
    struct Pick {
        bool cmd = false;
        int idx = -1;
    };
    Pick quickPick(const vector<string>& files, const vector<string>& cmds, string q) {
        int cs = 0, top = 0;
        vector<int> res;
        string lastq = "\x01";
        bool cmdMode = false, redraw = true;
        while (true) {
            if (q != lastq) {
                lastq = q;
                cmdMode = !q.empty() && q[0] == '>';
                const vector<string>& src = cmdMode ? cmds : files;
                string nd = cmdMode ? trim(q.substr(1)) : q;
                vector<std::pair<int, int>> sc;
                for (int i = 0; i < (int)src.size(); i++) {
                    int v = 0;
                    if (nd.empty() || fuzzy(nd, src[i], v)) sc.push_back({v, i});
                }
                if (!nd.empty())
                    std::stable_sort(sc.begin(), sc.end(), [](const std::pair<int, int>& a, const std::pair<int, int>& b) { return a.first > b.first; });
                res.clear();
                for (auto& e : sc) { res.push_back(e.second); if (res.size() >= 2000) break; }
                cs = 0; top = 0; redraw = true;
            }
            if (redraw) {
                redraw = false;
                int R, C;
                t.size(R, C);
                int vis = std::max(1, R - 2);
                cs = std::max(0, std::min(cs, (int)res.size() - 1));
                if (cs < top) top = cs;
                if (cs >= top + vis) top = cs - vis + 1;
                const vector<string>& src = cmdMode ? cmds : files;
                string label = cmdMode ? "Команда: " : "Файл: ";
                string out = "\x1b[?25l\x1b[1;1H\x1b[1m" + label + "\x1b[0m" + q + "\x1b[K";
                for (int r = 0; r < vis; r++) {
                    int i = top + r;
                    out += "\x1b[" + std::to_string(r + 2) + ";1H";
                    if (i < (int)res.size()) out += (i == cs ? stActive : string()) + ucut(src[res[i]], C - 1) + "\x1b[0m";
                    out += "\x1b[K";
                }
                out += "\x1b[" + std::to_string(R) + ";1H" + gutStr + "Enter — выбрать   Esc — закрыть   > — команды   " +
                       std::to_string(res.size()) + "\x1b[0m\x1b[K";
                out += "\x1b[1;" + std::to_string(ulen(label) + ulen(q) + 1) + "H\x1b[?25h";
                t.write(out);
            }
            Key k = readKey();
            if (k.c == K_NONE) continue;
            redraw = true;
            int vis = std::max(1, rows - 2);
            if (k.c == K_ESC) return Pick();
            if (k.c == K_ENTER) {
                if (res.empty()) continue;
                Pick r;
                r.cmd = cmdMode;
                r.idx = res[cs];
                return r;
            }
            if (k.c == K_BS) { if (!q.empty()) q.erase(prevx(q, (int)q.size())); }
            else if (k.c == K_CHAR && !k.ctrl && !k.alt) q += k.text;
            else if (k.c == K_PASTE) q += k.text.substr(0, k.text.find('\n'));
            else if (k.c == K_UP || (k.ctrl && k.c == 'p')) cs--;
            else if (k.c == K_DOWN || (k.ctrl && k.c == 'n')) cs++;
            else if (k.c == K_PGUP) cs -= vis;
            else if (k.c == K_PGDN) cs += vis;
            else if (k.c == K_MOUSE && (k.mb == 64 || k.mb == 65)) cs += k.mb == 64 ? -3 : 3;
        }
    }
    void quickOpen(const string& initial) {
        vector<string> files;
        std::unordered_set<string> seen;
        for (auto& tb : tabs)
            for (auto& pn : tb.panes) {
                if (pn.doc->path.empty()) continue;
                string nm = std::filesystem::path(pn.doc->path).lexically_normal().generic_string();
                if (seen.insert(nm).second) files.push_back(nm);
            }
        for (auto& f : projectFiles()) if (seen.insert(f).second) files.push_back(f);
        vector<string> ids, titles;
        for (auto& a : actionList) {
            if (a.second.empty()) continue;
            string key;
            for (auto& kv : binds) if (kv.second == a.first && (key.empty() || kv.first.size() < key.size())) key = kv.first;
            titles.push_back(a.second + (key.empty() ? string() : "    [" + key + "]"));
            ids.push_back(a.first);
        }
        Pick r = quickPick(files, titles, initial);
        prev.clear();
        if (r.idx < 0) return;
        if (r.cmd) runAction(ids[r.idx]);
        else openInTab(files[r.idx]);
    }


    void setMsg(const string& s) {
        msg = s;
        msgUntil = std::chrono::steady_clock::now() + std::chrono::seconds(4);
    }

    // ── язык ──
    void detectLang() {
        detectLang0();
        if (!cfg.highlight) d->hlOn = false;
    }
    void detectLang0() {
        string ext;
        size_t dot = d->path.rfind('.');
        if (dot != string::npos) ext = d->path.substr(dot + 1);
        for (auto& c : ext) c = (char)tolower(c);
        d->validUpTo = 0;
        d->lstate.assign(1, 0);
        d->blockOpen.clear();
        d->blockClose.clear();
        d->triple = false;
        d->kws.clear();
        d->lineComment.clear();
        d->hlOn = false;
        d->backtick = false;
        d->langName = "text";
        auto add = [&](const char* list) {
            string w;
            for (const char* p = list;; p++) {
                if (*p == ' ' || !*p) { if (!w.empty()) d->kws.insert(w); w.clear(); if (!*p) break; }
                else w += *p;
            }
        };
        static const char* cfam[] = {"c", "h", "cpp", "hpp", "cc", "cxx", "hh", "java", "js", "jsx", "ts", "tsx",
                                     "go", "rs", "cs", "swift", "kt", "php", "dart", "mjs"};
        for (auto e : cfam) if (ext == e) {
            d->hlOn = true; d->lineComment = "//"; d->langName = ext; d->blockOpen = "/*"; d->blockClose = "*/"; d->backtick = (ext == "js" || ext == "ts" || ext == "go" || ext == "jsx" || ext == "tsx");
            add("if else for while do switch case break continue return goto default static const constexpr "
                "struct class enum union typedef using namespace template typename public private protected virtual "
                "override final new delete this nullptr null true false void int char bool float double long short "
                "unsigned signed auto sizeof try catch throw finally import export from function let var async await "
                "yield extends implements interface package fn pub mut impl trait match mod use crate self Self "
                "func defer go chan map range type extern inline volatile register in of is as not and or "
                "string byte def elif with lambda pass");
        }
        if (ext == "py") {
            d->hlOn = true; d->lineComment = "#"; d->langName = "python"; d->triple = true;
            add("def class return if elif else for while in not and or is None True False import from as try except "
                "finally raise with lambda pass break continue yield global nonlocal assert del async await self");
        } else if (ext == "sh" || ext == "bash" || ext == "zsh") {
            d->hlOn = true; d->lineComment = "#"; d->langName = "shell";
            add("if then else elif fi for while do done case esac function in return export local echo exit source");
        } else if (ext == "toml" || ext == "yaml" || ext == "yml" || ext == "conf" || ext == "ini" || ext == "cmake") {
            d->hlOn = true; d->lineComment = "#"; d->langName = ext;
        } else if (ext == "json") {
            d->hlOn = true; d->langName = "json";
            add("true false null");
        } else if (ext == "css" || ext == "scss") {
            d->hlOn = true; d->langName = ext; d->blockOpen = "/*"; d->blockClose = "*/";
            if (ext == "scss") d->lineComment = "//";
        } else if (ext == "html" || ext == "htm" || ext == "xml" || ext == "md") {
            d->hlOn = true; d->langName = ext; d->blockOpen = "<!--"; d->blockClose = "-->";
        } else if (ext == "lua" || ext == "sql") {
            d->hlOn = true; d->lineComment = "--"; d->langName = ext;
            add("function end if then else elseif for while do return local nil true false and or not select from where insert into update delete create table");
        }
    }
    bool hasMulti() const { return d->hlOn && (!d->blockOpen.empty() || d->triple || d->backtick); }
    // Разбор строки. h — классы подсветки (может быть nullptr), state — многострочное состояние:
    // 0 нет, 1 блочный комментарий, 2 """, 3 ''', 4 `
    void scan(const string& s, vector<unsigned char>* h, int& state) {
        size_t n = s.size(), i = 0;
        if (h) h->assign(n, H_NORM);
        if (!d->hlOn) return;
        auto fill = [&](size_t a, size_t b, unsigned char c) { if (h) std::fill(h->begin() + a, h->begin() + b, c); };
        while (i < n) {
            if (state) {
                string close = state == 1 ? d->blockClose : state == 2 ? string("\"\"\"") : state == 3 ? string("\'\'\'") : string("`");
                unsigned char cls = state == 1 ? H_COM : H_STR;
                size_t e = s.find(close, i);
                if (e == string::npos) { fill(i, n, cls); return; }
                size_t end = e + close.size();
                fill(i, end, cls);
                i = end;
                state = 0;
                continue;
            }
            unsigned char c = s[i];
            if (!d->lineComment.empty() && s.compare(i, d->lineComment.size(), d->lineComment) == 0) {
                fill(i, n, H_COM);
                return;
            }
            if (!d->blockOpen.empty() && s.compare(i, d->blockOpen.size(), d->blockOpen) == 0) {
                fill(i, i + d->blockOpen.size(), H_COM);
                i += d->blockOpen.size();
                state = 1;
                continue;
            }
            if (d->triple && (c == '"' || c == '\'') && s.compare(i, 3, string(3, (char)c)) == 0) {
                fill(i, i + 3, H_STR);
                i += 3;
                state = c == '"' ? 2 : 3;
                continue;
            }
            if (c == '`' && d->backtick) { fill(i, i + 1, H_STR); i++; state = 4; continue; }
            if (c == '"' || c == '\'') {
                size_t j = i + 1;
                while (j < n && s[j] != (char)c) { if (s[j] == '\\') j++; j++; }
                j = std::min(j + 1, n);
                fill(i, j, H_STR);
                i = j;
                continue;
            }
            if (isdigit(c) && (i == 0 || !isident(s[i - 1]))) {
                size_t j = i;
                while (j < n && (isalnum((unsigned char)s[j]) || s[j] == '.' || s[j] == '_')) j++;
                fill(i, j, H_NUM);
                i = j;
                continue;
            }
            if (isalpha(c) || c == '_') {
                size_t j = i;
                while (j < n && isident(s[j])) j++;
                if (h) {
                    string w = s.substr(i, j - i);
                    unsigned char cls = H_NORM;
                    if (d->kws.count(w)) cls = H_KW;
                    else {
                        size_t k = j;
                        while (k < n && s[k] == ' ') k++;
                        if (k < n && s[k] == '(') cls = H_FN;
                    }
                    if (cls) fill(i, j, cls);
                }
                i = j;
                continue;
            }
            i++;
        }
    }
    // состояние в начале строки y (кэшируется; при правке инвалидируется с изменённой строки)
    int stateAt(int y) {
        if (!hasMulti()) return 0;
        if (y - d->validUpTo > 300000) {
            int s0 = 0;
            for (int i = y - 5000; i < y; i++) scan(d->L[i], nullptr, s0);
            return s0;
        }
        if ((int)d->lstate.size() <= d->validUpTo) d->lstate.resize(d->validUpTo + 1);
        while (d->validUpTo < y) {
            int s0 = d->lstate[d->validUpTo];
            scan(d->L[d->validUpTo], nullptr, s0);
            d->validUpTo++;
            if ((int)d->lstate.size() <= d->validUpTo) d->lstate.resize(d->validUpTo + 1);
            d->lstate[d->validUpTo] = (unsigned char)s0;
        }
        return d->lstate[y];
    }

    // ── файл ──
    void load(const string& p) {
        d->path = p;
        detectLang();
        std::ifstream f(p, std::ios::binary);
        if (!f) { setMsg("Новый файл"); return; }
        string data((std::istreambuf_iterator<char>(f)), {});
        d->crlf = data.find("\r\n") != string::npos;
        d->finalNL = data.empty() || data.back() == '\n';
        d->L.clear();
        size_t beg = 0;
        while (beg <= data.size()) {
            size_t e = data.find('\n', beg);
            if (e == string::npos) { d->L.push_back(data.substr(beg)); break; }
            size_t end = e;
            if (d->crlf && end > beg && data[end - 1] == '\r') end--;
            d->L.emplace_back(data, beg, end - beg);
            beg = e + 1;
        }
        if (d->finalNL && d->L.size() > 1 && d->L.back().empty()) d->L.pop_back();
        if (d->L.empty()) d->L.push_back("");
        d->validUpTo = 0;
        d->lstate.assign(1, 0);
    }
    bool save() {
        if (d->path.empty()) {
            string p;
            if (!prompt("Сохранить как: ", p) || p.empty()) { setMsg("Отменено"); return false; }
            d->path = p;
            detectLang();
        }
        std::ofstream f(d->path, std::ios::binary | std::ios::trunc);
        if (!f) { setMsg("Ошибка: не удалось записать " + d->path); return false; }
        string out;
        for (size_t i = 0; i < d->L.size(); i++) {
            out += d->L[i];
            if (i + 1 < d->L.size() || d->finalNL) out += d->crlf ? "\r\n" : "\n";
        }
        f.write(out.data(), (std::streamsize)out.size());
        d->dirty = false;
        setMsg("Сохранено: " + std::to_string(d->L.size()) + " строк");
        if (sameFile(d->path, cfgPath())) { loadConfig(); if (cfgError.empty()) setMsg("Конфиг применён"); }
        return true;
    }

    // ── низкоуровневые операции ──
    string getText(Pos a, Pos b) {
        if (a.y == b.y) return d->L[a.y].substr(a.x, b.x - a.x);
        string s = d->L[a.y].substr(a.x) + "\n";
        for (int y = a.y + 1; y < b.y; y++) { s += d->L[y]; s += '\n'; }
        s += d->L[b.y].substr(0, b.x);
        return s;
    }
    void rawErase(Pos a, Pos b) {
        d->validUpTo = std::min(d->validUpTo, a.y);
        if (a.y == b.y) d->L[a.y].erase(a.x, b.x - a.x);
        else {
            d->L[a.y] = d->L[a.y].substr(0, a.x) + d->L[b.y].substr(b.x);
            d->L.erase(d->L.begin() + a.y + 1, d->L.begin() + b.y + 1);
        }
    }
    Pos rawInsert(Pos p, const string& s) {
        d->validUpTo = std::min(d->validUpTo, p.y);
        size_t nl = s.find('\n');
        if (nl == string::npos) {
            d->L[p.y].insert(p.x, s);
            return {p.y, p.x + (int)s.size()};
        }
        string tail = d->L[p.y].substr(p.x);
        d->L[p.y].resize(p.x);
        vector<string> parts;
        size_t st = 0;
        while (true) {
            size_t e = s.find('\n', st);
            if (e == string::npos) { parts.push_back(s.substr(st)); break; }
            parts.push_back(s.substr(st, e - st));
            st = e + 1;
        }
        d->L[p.y] += parts[0];
        int last = (int)parts.size() - 1;
        int endx = (int)parts[last].size();
        parts[last] += tail;
        d->L.insert(d->L.begin() + p.y + 1, parts.begin() + 1, parts.end());
        return {p.y + last, endx};
    }
    static Pos endOf(Pos at, const string& s) {
        size_t nl = s.rfind('\n');
        if (nl == string::npos) return {at.y, at.x + (int)s.size()};
        int n = (int)std::count(s.begin(), s.end(), '\n');
        return {at.y + n, (int)(s.size() - nl - 1)};
    }
    void beginGroup() { d->inGrp = true; d->grp = d->nextG++; }
    void endGroup() { d->inGrp = false; }

    void edit(Pos a, Pos b, const string& ins, bool merge = false) {
        Edit e;
        e.at = a;
        e.removed = getText(a, b);
        e.inserted = ins;
        e.cb = cur;
        rawErase(a, b);
        Pos end = rawInsert(a, ins);
        cur = end;
        e.ca = cur;
        want = dcol(d->L[cur.y], cur.x);
        d->dirty = true;
        d->redo.clear();
        if (merge && !d->noMerge && !d->inGrp && !d->undo.empty()) {
            Edit& l = d->undo.back();
            if (l.removed.empty() && l.inserted.size() < 200 && l.inserted.find('\n') == string::npos &&
                endOf(l.at, l.inserted) == a) {
                l.inserted += ins;
                l.ca = cur;
                return;
            }
        }
        e.g = d->inGrp ? d->grp : d->nextG++;
        d->undo.push_back(std::move(e));
        d->noMerge = !merge;
    }
    void doUndo() {
        if (d->undo.empty()) { setMsg("Нечего отменять"); return; }
        int g = d->undo.back().g;
        while (!d->undo.empty() && d->undo.back().g == g) {
            Edit e = d->undo.back();
            d->undo.pop_back();
            rawErase(e.at, endOf(e.at, e.inserted));
            rawInsert(e.at, e.removed);
            cur = e.cb;
            d->redo.push_back(std::move(e));
        }
        sel = false; d->noMerge = true; d->dirty = true;
        clampCur();
    }
    void doRedo() {
        if (d->redo.empty()) { setMsg("Нечего повторять"); return; }
        int g = d->redo.back().g;
        while (!d->redo.empty() && d->redo.back().g == g) {
            Edit e = d->redo.back();
            d->redo.pop_back();
            rawErase(e.at, endOf(e.at, e.removed));
            rawInsert(e.at, e.inserted);
            cur = e.ca;
            d->undo.push_back(std::move(e));
        }
        sel = false; d->noMerge = true; d->dirty = true;
        clampCur();
    }
    void clampCur() {
        cur.y = std::max(0, std::min(cur.y, (int)d->L.size() - 1));
        cur.x = std::max(0, std::min(cur.x, (int)d->L[cur.y].size()));
        want = dcol(d->L[cur.y], cur.x);
    }

    // ── выделение ──
    bool getSel(Pos& a, Pos& b) {
        if (!sel || anc == cur) return false;
        if (anc < cur) { a = anc; b = cur; } else { a = cur; b = anc; }
        return true;
    }
    bool deleteSel() {
        Pos a, b;
        if (!getSel(a, b)) { sel = false; return false; }
        edit(a, b, "");
        sel = false;
        return true;
    }
    void moveTo(Pos p, bool extend, bool keepWant = false) {
        if (extend) { if (!sel) { sel = true; anc = cur; } }
        else sel = false;
        cur = p;
        d->noMerge = true;
        if (!keepWant) want = dcol(d->L[cur.y], cur.x);
    }

    // ── редактирование ──
    void insertText(const string& s, bool merge = false) {
        Pos a, b;
        if (getSel(a, b)) { edit(a, b, s); sel = false; }
        else { sel = false; edit(cur, cur, s, merge); }
    }
    string indentOf(const string& s, int upto) {
        int i = 0;
        while (i < upto && (s[i] == ' ' || s[i] == '\t')) i++;
        return s.substr(0, i);
    }
    void enter() {
        deleteSel();
        string& s = d->L[cur.y];
        string ind = cfg.autoIndent ? indentOf(s, cur.x) : string();
        char before = cur.x > 0 ? s[cur.x - 1] : 0;
        char after = cur.x < (int)s.size() ? s[cur.x] : 0;
        bool open = before == '{' || before == '(' || before == '[' || (before == ':' && d->langName == "python");
        string extra = (open && cfg.autoIndent) ? indentUnit() : string();
        if ((before == '{' && after == '}') || (before == '(' && after == ')') || (before == '[' && after == ']')) {
            edit(cur, cur, "\n" + ind + extra + "\n" + ind);
            cur = {cur.y - 1, (int)(ind.size() + extra.size())};
            d->undo.back().ca = cur;
            want = dcol(d->L[cur.y], cur.x);
        } else {
            edit(cur, cur, "\n" + ind + extra);
        }
    }
    void backspace() {
        if (deleteSel()) return;
        if (cur.x > 0 && cur.x < (int)d->L[cur.y].size()) {
            char p = d->L[cur.y][cur.x - 1], n = d->L[cur.y][cur.x];
            if ((p == '(' && n == ')') || (p == '[' && n == ']') || (p == '{' && n == '}') ||
                (d->hlOn && (p == '"' || p == '\'' || p == '`') && n == p)) {
                edit({cur.y, cur.x - 1}, {cur.y, cur.x + 1}, "");
                return;
            }
        }
        if (cur.x > 0) {
            const string& s = d->L[cur.y];
            int px = prevx(s, cur.x);
            bool allsp = true;
            for (int i = 0; i < cur.x; i++) if (s[i] != ' ') { allsp = false; break; }
            if (allsp) px = std::max(0, cur.x - ((cur.x - 1) % TAB + 1));
            edit({cur.y, px}, cur, "");
        } else if (cur.y > 0) edit({cur.y - 1, (int)d->L[cur.y - 1].size()}, cur, "");
    }
    void del() {
        if (deleteSel()) return;
        const string& s = d->L[cur.y];
        if (cur.x < (int)s.size()) edit(cur, {cur.y, nextx(s, cur.x)}, "");
        else if (cur.y + 1 < (int)d->L.size()) edit(cur, {cur.y + 1, 0}, "");
    }
    void lineRange(int& y1, int& y2) {
        Pos a, b;
        if (getSel(a, b)) { y1 = a.y; y2 = b.y; if (b.x == 0 && y2 > y1) y2--; }
        else y1 = y2 = cur.y;
    }
    void tab(bool shift) {
        Pos a, b;
        bool multi = getSel(a, b) && a.y != b.y;
        if (!shift && !multi) {
            deleteSel();
            int c = dcol(d->L[cur.y], cur.x);
            insertText(cfg.expandTab ? string(TAB - c % TAB, ' ') : string("\t"), true);
            return;
        }
        int y1, y2;
        lineRange(y1, y2);
        beginGroup();
        for (int y = y1; y <= y2; y++) {
            if (!shift) { if (!d->L[y].empty()) edit({y, 0}, {y, 0}, indentUnit()); }
            else {
                int n = 0;
                while (n < TAB && n < (int)d->L[y].size() && d->L[y][n] == ' ') n++;
                if (n == 0 && !d->L[y].empty() && d->L[y][0] == '\t') n = 1;
                if (n) edit({y, 0}, {y, n}, "");
            }
        }
        endGroup();
        if (multi) { anc = {y1, 0}; cur = {y2, (int)d->L[y2].size()}; sel = true; }
        else { sel = false; cur.x = std::min(cur.x, (int)d->L[cur.y].size()); }
        want = dcol(d->L[cur.y], cur.x);
    }
    void toggleComment() {
        if (d->lineComment.empty()) { setMsg("Для этого типа файла комментарии не заданы"); return; }
        int y1, y2;
        lineRange(y1, y2);
        bool allc = true;
        for (int y = y1; y <= y2; y++) {
            const string& s = d->L[y];
            size_t i = s.find_first_not_of(" \t");
            if (i == string::npos) continue;
            if (s.compare(i, d->lineComment.size(), d->lineComment) != 0) { allc = false; break; }
        }
        beginGroup();
        for (int y = y1; y <= y2; y++) {
            const string& s = d->L[y];
            size_t i = s.find_first_not_of(" \t");
            if (i == string::npos) continue;
            if (allc) {
                size_t n = d->lineComment.size();
                if (i + n < s.size() && s[i + n] == ' ') n++;
                edit({y, (int)i}, {y, (int)(i + n)}, "");
            } else edit({y, (int)i}, {y, (int)i}, d->lineComment + " ");
        }
        endGroup();
        sel = false;
        clampCur();
    }
    void deleteLines() {
        int y1, y2;
        lineRange(y1, y2);
        if (y2 + 1 < (int)d->L.size()) edit({y1, 0}, {y2 + 1, 0}, "");
        else if (y1 > 0) edit({y1 - 1, (int)d->L[y1 - 1].size()}, {y2, (int)d->L[y2].size()}, "");
        else edit({0, 0}, {y2, (int)d->L[y2].size()}, "");
        sel = false;
        cur.x = std::min(want == 0 ? 0 : cur.x, (int)d->L[cur.y].size());
        clampCur();
    }
    void duplicateLines() {
        int y1, y2;
        lineRange(y1, y2);
        Pos save = cur;
        string block = getText({y1, 0}, {y2, (int)d->L[y2].size()});
        int n = y2 - y1 + 1;
        edit({y2, (int)d->L[y2].size()}, {y2, (int)d->L[y2].size()}, "\n" + block);
        cur = {save.y + n, save.x};
        d->undo.back().ca = cur;
        sel = false;
        clampCur();
    }
    void moveLines(int dir) {
        int y1, y2;
        lineRange(y1, y2);
        if ((dir < 0 && y1 == 0) || (dir > 0 && y2 + 1 >= (int)d->L.size())) return;
        Pos sc = cur, sa = anc;
        bool hs = sel;
        string blk = getText({y1, 0}, {y2, (int)d->L[y2].size()});
        if (dir < 0) {
            string other = d->L[y1 - 1];
            edit({y1 - 1, 0}, {y2, (int)d->L[y2].size()}, blk + "\n" + other);
        } else {
            string other = d->L[y2 + 1];
            edit({y1, 0}, {y2 + 1, (int)d->L[y2 + 1].size()}, other + "\n" + blk);
        }
        cur = {sc.y + dir, sc.x};
        anc = {sa.y + dir, sa.x};
        sel = hs;
        d->undo.back().ca = cur;
        want = dcol(d->L[cur.y], cur.x);
    }

    // ── буфер обмена ──
    void setClip(const string& s, bool line) {
        clip = s;
        clipLine = line;
        t.write("\x1b]52;c;" + b64(s) + "\x07");
#ifndef _WIN32
        if (getenv("TERMUX_VERSION")) {
            if (FILE* p = popen("termux-clipboard-set 2>/dev/null", "w")) {
                fwrite(s.data(), 1, s.size(), p);
                pclose(p);
            }
        }
#endif
    }
    void copy(bool cut) {
        Pos a, b;
        if (getSel(a, b)) {
            setClip(getText(a, b), false);
            if (cut) deleteSel();
        } else {
            setClip(d->L[cur.y] + "\n", true);
            if (cut) deleteLines();
        }
        setMsg(cut ? "Вырезано" : "Скопировано");
    }
    void paste() {
        string s = clip;
        bool line = clipLine;
#ifndef _WIN32
        if (getenv("TERMUX_VERSION")) {
            if (FILE* p = popen("termux-clipboard-get 2>/dev/null", "r")) {
                string r;
                char b[4096];
                size_t n;
                while ((n = fread(b, 1, sizeof b, p)) > 0) r.append(b, n);
                pclose(p);
                if (!r.empty() && r != clip) { s = r; line = false; }
            }
        }
#endif
        if (s.empty()) return;
        if (line && !getSelQuick()) {
            cur.x = 0;
            edit(cur, cur, s);
            cur.y = std::min(cur.y, (int)d->L.size() - 1);
            cur.x = 0;
            clampCur();
        } else insertText(normalize(s));
    }
    bool getSelQuick() { Pos a, b; return getSel(a, b); }
    static string normalize(const string& s) {
        string o;
        for (size_t i = 0; i < s.size(); i++) {
            if (s[i] == '\r') { if (i + 1 < s.size() && s[i + 1] == '\n') continue; o += '\n'; }
            else o += s[i];
        }
        return o;
    }

    // ── навигация ──
    void wordLeft(bool ext) {
        Pos p = cur;
        if (p.x == 0) { if (p.y > 0) p = {p.y - 1, (int)d->L[p.y - 1].size()}; moveTo(p, ext); return; }
        const string& s = d->L[p.y];
        int x = p.x;
        while (x > 0 && !isident(s[x - 1]) && isspace((unsigned char)s[x - 1])) x--;
        if (x > 0 && isident(s[x - 1])) { while (x > 0 && isident(s[x - 1])) x--; }
        else if (x > 0) x--;
        moveTo({p.y, x}, ext);
    }
    void wordRight(bool ext) {
        Pos p = cur;
        const string& s = d->L[p.y];
        int n = (int)s.size();
        if (p.x >= n) { if (p.y + 1 < (int)d->L.size()) p = {p.y + 1, 0}; moveTo(p, ext); return; }
        int x = p.x;
        if (isident(s[x])) { while (x < n && isident(s[x])) x++; }
        else if (!isspace((unsigned char)s[x])) x++;
        while (x < n && isspace((unsigned char)s[x])) x++;
        moveTo({p.y, x}, ext);
    }
    void vmove(int dy, bool ext) {
        int y = cur.y + dy;
        if (y < 0) { moveTo({0, 0}, ext); return; }
        if (y >= (int)d->L.size()) { moveTo({(int)d->L.size() - 1, (int)d->L.back().size()}, ext); return; }
        moveTo({y, col2x(d->L[y], want)}, ext, true);
    }
    void smartHome(bool ext) {
        const string& s = d->L[cur.y];
        int f = 0;
        while (f < (int)s.size() && (s[f] == ' ' || s[f] == '\t')) f++;
        moveTo({cur.y, cur.x == f ? 0 : f}, ext);
    }

    // ── поиск ──
    static string lower(string s) { for (auto& c : s) c = (char)tolower((unsigned char)c); return s; }
    bool findFrom(const string& q, Pos from, bool fwd, Pos& a, Pos& b, bool wrap = true) {
        if (q.empty()) return false;
        bool ci = q == lower(q);
        string qq = ci ? q : q;
        int n = (int)d->L.size();
        int iters = wrap ? n : (fwd ? n - 1 - from.y : from.y);
        for (int i = 0; i <= iters; i++) {
            int y = fwd ? (from.y + i) % n : ((from.y - i) % n + n) % n;
            string line = ci ? lower(d->L[y]) : d->L[y];
            size_t pos = string::npos;
            if (fwd) {
                size_t st = (i == 0) ? from.x : 0;
                if (i == n) st = 0;
                if (st <= line.size()) pos = line.find(qq, st);
                if (i == n && pos != string::npos && (int)pos >= from.x && from.y == y) pos = string::npos;
            } else {
                if (i == 0) { if (from.x > 0) pos = line.rfind(qq, from.x - 1); }
                else pos = line.rfind(qq);
                if (i == n && pos != string::npos && (int)pos < from.x) pos = string::npos;
            }
            if (pos != string::npos) {
                a = {y, (int)pos};
                b = {y, (int)(pos + qq.size())};
                return true;
            }
        }
        return false;
    }
    void find() {
        Pos origin = cur;
        bool osel = sel;
        Pos oanc = anc;
        string q = lastQ;
        auto showMatch = [&](Pos from, bool fwd) {
            Pos a, b;
            if (findFrom(promptText, from, fwd, a, b)) { anc = a; cur = b; sel = true; }
            else setMsg("Не найдено");
        };
        auto onChange = [&](const string& s) {
            if (s.empty()) { cur = origin; sel = false; return; }
            showMatch(origin, true);
        };
        auto onNav = [&](int d) {
            if (promptText.empty()) return;
            Pos from = d > 0 ? cur : (sel ? anc : cur);
            showMatch(from, d > 0);
        };
        promptText = q;
        if (prompt("Найти: ", q, onChange, onNav, true)) lastQ = q;
        else { cur = origin; sel = osel; anc = oanc; }
        clampCur();
    }
    void findNext(bool fwd) {
        if (lastQ.empty()) { find(); return; }
        Pos a, b, from = fwd ? cur : (sel ? anc : cur);
        if (findFrom(lastQ, from, fwd, a, b)) { anc = a; cur = b; sel = true; want = dcol(d->L[cur.y], cur.x); }
        else setMsg("Не найдено: " + lastQ);
    }
    void gotoLine() {
        string s;
        if (!prompt("Перейти к строке[:колонка]: ", s) || s.empty()) return;
        int y = 0, c = 1;
        sscanf(s.c_str(), "%d:%d", &y, &c);
        y = std::max(1, std::min(y, (int)d->L.size()));
        moveTo({y - 1, col2x(d->L[y - 1], std::max(0, c - 1))}, false);
        rowoff = std::max(0, cur.y - textRows / 2);
    }

    // ── автозакрытие скобок и кавычек ──
    void typeChar(const string& text) {
        if (cfg.autoPair && text.size() == 1) {
            char c = text[0];
            const char* openers = "([{\"'`";
            const char* pairs = ")]}\"'`";
            const char* op = strchr(openers, c);
            Pos a, b;
            bool hasSel = getSel(a, b);
            if (!hasSel) sel = false;
            if (op && hasSel) {
                string inner = getText(a, b);
                edit(a, b, string(1, c) + inner + pairs[op - openers]);
                Pos is{a.y, a.x + 1};
                anc = is;
                cur = endOf(is, inner);
                sel = true;
                d->undo.back().ca = cur;
                d->noMerge = true;
                return;
            }
            if (!hasSel) {
                const string& s = d->L[cur.y];
                char n = cur.x < (int)s.size() ? s[cur.x] : 0;
                char p = cur.x > 0 ? s[cur.x - 1] : 0;
                bool quote = c == '"' || c == '\'' || c == '`';
                if ((c == ')' || c == ']' || c == '}' || (quote && d->hlOn)) && n == c) {
                    moveTo({cur.y, cur.x + 1}, false);
                    return;
                }
                if (op && (!quote || d->hlOn)) {
                    bool okNext = n == 0 || isspace((unsigned char)n) || strchr(")]},;:.", n);
                    bool okPrev = !quote || !(isident(p) || p == c);
                    if (okNext && okPrev) {
                        edit(cur, cur, string(1, c) + pairs[op - openers]);
                        cur.x--;
                        d->undo.back().ca = cur;
                        want = dcol(d->L[cur.y], cur.x);
                        return;
                    }
                }
            }
        }
        insertText(text, true);
    }

    // ── парные скобки ──
    void computeMatch() {
        mA = mB = {-1, -1};
        if (getSelQuick()) return;
        const string& s = d->L[cur.y];
        int x = -1;
        if (cur.x < (int)s.size() && strchr("()[]{}", s[cur.x])) x = cur.x;
        else if (cur.x > 0 && strchr("()[]{}", s[cur.x - 1])) x = cur.x - 1;
        if (x < 0) return;
        char c = s[x], partner;
        int dir;
        switch (c) {
            case '(': partner = ')'; dir = 1; break;
            case '[': partner = ']'; dir = 1; break;
            case '{': partner = '}'; dir = 1; break;
            case ')': partner = '('; dir = -1; break;
            case ']': partner = '['; dir = -1; break;
            default: partner = '{'; dir = -1; break;
        }
        int depth = 1, y = cur.y, i = x + dir, lines = 0;
        while (y >= 0 && y < (int)d->L.size() && lines < 3000) {
            const string& ln = d->L[y];
            for (; i >= 0 && i < (int)ln.size(); i += dir) {
                if (ln[i] == c) depth++;
                else if (ln[i] == partner && --depth == 0) { mA = {cur.y, x}; mB = {y, i}; return; }
            }
            y += dir;
            lines++;
            if (y >= 0 && y < (int)d->L.size()) i = dir > 0 ? 0 : (int)d->L[y].size() - 1;
        }
    }

    // ── замена ──
    void replaceFlow() {
        string q, r;
        if (!prompt("Заменить: ", q) || q.empty()) return;
        if (!prompt("Заменить на: ", r)) return;
        Pos oc = cur, oa = anc;
        bool os = sel, all = false;
        int count = 0;
        Pos from{0, 0};
        beginGroup();
        while (true) {
            Pos a, b;
            if (!findFrom(q, from, true, a, b, false)) break;
            if (!all) {
                anc = a; cur = b; sel = true;
                msg = "Заменить? y — да   n — пропустить   a — все   Esc — стоп";
                msgUntil = std::chrono::steady_clock::now() + std::chrono::hours(1);
                draw();
                int choice = 0;
                while (!choice) {
                    Key k = readKey();
                    if (k.c == K_NONE) continue;
                    if (k.c == K_ESC) choice = 3;
                    else if (k.c == K_CHAR && !k.text.empty()) {
                        char ch = (char)tolower((unsigned char)k.text[0]);
                        if (ch == 'y') choice = 1; else if (ch == 'n') choice = 2; else if (ch == 'a') choice = 4;
                    }
                }
                if (choice == 3) break;
                if (choice == 2) { from = b; continue; }
                if (choice == 4) all = true;
            }
            sel = false;
            edit(a, b, r);
            count++;
            from = cur;
        }
        endGroup();
        sel = false;
        if (!count) { cur = oc; anc = oa; sel = os; }
        clampCur();
        setMsg("Заменено: " + std::to_string(count));
    }

    // ── файлы ──
    void openPrompt() {
        string p;
        if (!prompt("Открыть файл в этой панели: ", p) || p.empty()) return;
        openHere(p);
    }
    int listPicker(const string& title, const vector<string>& items) {
        int cs = 0, top = 0;
        while (true) {
            int R, C;
            t.size(R, C);
            int vis = std::max(1, R - 2);
            if (cs < top) top = cs;
            if (cs >= top + vis) top = cs - vis + 1;
            string out = "\x1b[?25l\x1b[1;1H\x1b[7m" + ucut(title, C) + "\x1b[K\x1b[0m";
            for (int r = 0; r < vis; r++) {
                int i = top + r;
                out += "\x1b[" + std::to_string(r + 2) + ";1H";
                if (i < (int)items.size()) out += (i == cs ? "\x1b[7m" : "") + ucut(items[i], C - 1) + "\x1b[0m";
                out += "\x1b[K";
            }
            out += "\x1b[" + std::to_string(R) + ";1H\x1b[38;5;240mEnter — открыть   Esc — закрыть   " +
                   std::to_string(cs + 1) + "/" + std::to_string(items.size()) + "\x1b[0m\x1b[K";
            t.write(out);
            Key k = readKey();
            int n = (int)items.size();
            if (k.c == K_ESC) { prev.clear(); return -1; }
            if (k.c == K_ENTER) { prev.clear(); return cs; }
            if (k.c == K_UP) cs = std::max(0, cs - 1);
            else if (k.c == K_DOWN) cs = std::min(n - 1, cs + 1);
            else if (k.c == K_PGUP) cs = std::max(0, cs - vis);
            else if (k.c == K_PGDN) cs = std::min(n - 1, cs + vis);
            else if (k.c == K_HOME) cs = 0;
            else if (k.c == K_END) cs = n - 1;
            else if (k.c == K_MOUSE && (k.mb == 64 || k.mb == 65)) cs = std::max(0, std::min(n - 1, cs + (k.mb == 64 ? -3 : 3)));
        }
    }
    void grepFiles() {
        namespace fs = std::filesystem;
        string q;
        if (!prompt("Искать в файлах: ", q) || q.empty()) return;
        setMsg("Поиск…");
        draw();
        struct R { string file; int line, col; };
        vector<R> res;
        vector<string> items;
        bool ci = q == lower(q);
        static const char* skip[] = {"node_modules", "build", "target", "dist", "__pycache__", "venv"};
        try {
            for (auto it = fs::recursive_directory_iterator(".", fs::directory_options::skip_permission_denied);
                 it != fs::recursive_directory_iterator() && res.size() < 5000; ++it) {
                string name = it->path().filename().string();
                if (it->is_directory()) {
                    bool sk = name.size() > 1 && name[0] == '.';
                    for (auto d : skip) if (name == d) sk = true;
                    if (sk) it.disable_recursion_pending();
                    continue;
                }
                if (!it->is_regular_file() || it->file_size() > 5000000) continue;
                std::ifstream f(it->path(), std::ios::binary);
                char head[4096];
                f.read(head, sizeof head);
                if (memchr(head, 0, (size_t)f.gcount())) continue;
                f.clear();
                f.seekg(0);
                string rel = it->path().string();
                if (rel.compare(0, 2, "./") == 0) rel = rel.substr(2);
                string line;
                int ln = 0;
                while (std::getline(f, line) && res.size() < 5000) {
                    ln++;
                    size_t pos = (ci ? lower(line) : line).find(q);
                    if (pos == string::npos) continue;
                    if (!line.empty() && line.back() == '\r') line.pop_back();
                    size_t ts = line.find_first_not_of(" \t");
                    res.push_back({rel, ln, (int)pos});
                    items.push_back(rel + ":" + std::to_string(ln) + ": " + (ts == string::npos ? "" : line.substr(ts, 200)));
                }
            }
        } catch (...) {}
        if (res.empty()) { setMsg("Не найдено: " + q); return; }
        int pick = listPicker(" Найдено: " + std::to_string(res.size()) + "  «" + q + "»", items);
        if (pick < 0) return;
        const R& r = res[pick];
        openInTab(r.file);
        int y = std::min(r.line - 1, (int)d->L.size() - 1);
        int x = std::min(r.col, (int)d->L[y].size());
        anc = {y, x};
        cur = {y, std::min(x + (int)q.size(), (int)d->L[y].size())};
        sel = true;
        want = dcol(d->L[y], cur.x);
        rowoff = std::max(0, y - textRows / 2);
    }

    // ── ввод ──
    Key csi(const string& p, int f) {
        Key k;
        if (!p.empty() && p[0] == '<') {
            int b = 0, x = 0, y = 0;
            sscanf(p.c_str() + 1, "%d;%d;%d", &b, &x, &y);
            k.c = K_MOUSE; k.mb = b; k.mx = x; k.my = y; k.release = (f == 'm');
            return k;
        }
        vector<int> v;
        {
            size_t st = 0;
            while (st <= p.size() && !p.empty()) {
                size_t e = p.find(';', st);
                v.push_back(atoi(p.substr(st, e == string::npos ? string::npos : e - st).c_str()));
                if (e == string::npos) break;
                st = e + 1;
            }
        }
        int p0 = v.size() > 0 ? v[0] : 0;
        int mod = v.size() > 1 ? v[1] - 1 : 0;
        k.shift = mod & 1; k.alt = mod & 2; k.ctrl = mod & 4;
        switch (f) {
            case 'A': k.c = K_UP; break;
            case 'B': k.c = K_DOWN; break;
            case 'C': k.c = K_RIGHT; break;
            case 'D': k.c = K_LEFT; break;
            case 'H': k.c = K_HOME; break;
            case 'F': k.c = K_END; break;
            case 'P': case 'Q': case 'R': case 'S': k.c = K_F1 + (f - 'P'); break;
            case 'Z': k.c = K_TAB; k.shift = true; break;
            case '~':
                switch (p0) {
                    case 1: case 7: k.c = K_HOME; break;
                    case 4: case 8: k.c = K_END; break;
                    case 3: k.c = K_DEL; break;
                    case 5: k.c = K_PGUP; break;
                    case 6: k.c = K_PGDN; break;
                    case 11: case 12: case 13: case 14: k.c = K_F1 + (p0 - 11); break;
                    case 15: k.c = K_F1 + 4; break;
                    case 17: case 18: case 19: k.c = K_F1 + 5 + (p0 - 17); break;
                    case 20: case 21: k.c = K_F1 + 8 + (p0 - 20); break;
                    case 23: case 24: k.c = K_F1 + 10 + (p0 - 23); break;
                    case 200: {
                        k.c = K_PASTE;
                        string d;
                        while (true) {
                            int b = t.readByte(300);
                            if (b < 0) break;
                            d += (char)b;
                            if (d.size() >= 6 && d.compare(d.size() - 6, 6, "\x1b[201~") == 0) { d.resize(d.size() - 6); break; }
                        }
                        k.text = d;
                        break;
                    }
                }
                break;
        }
        return k;
    }
    Key readKey() {
        Key k;
        int b = t.readByte(100);
        if (b < 0) return k;
        if (b == 27) {
            int n = t.readByte(25);
            if (n < 0) { k.c = K_ESC; return k; }
            if (n == '[') {
                string p;
                int f;
                while (true) {
                    f = t.readByte(50);
                    if (f < 0) return k;
                    if (f >= 0x40 && f <= 0x7e) break;
                    p += (char)f;
                }
                return csi(p, f);
            }
            if (n == 'O') {
                int f = t.readByte(50);
                switch (f) {
                    case 'A': k.c = K_UP; break;
                    case 'B': k.c = K_DOWN; break;
                    case 'C': k.c = K_RIGHT; break;
                    case 'D': k.c = K_LEFT; break;
                    case 'H': k.c = K_HOME; break;
                    case 'F': k.c = K_END; break;
                    case 'P': case 'Q': case 'R': case 'S': k.c = K_F1 + (f - 'P'); break;
                }
                return k;
            }
            k.alt = true;
            if (n == 27) { k.c = K_ESC; return k; }
            if (n == 127) { k.c = K_BS; return k; }
            k.c = K_CHAR;
            k.text = string(1, (char)n);
            return k;
        }
        if (b == 13 || b == 10) { k.c = K_ENTER; return k; }
        if (b == 9) { k.c = K_TAB; return k; }
        if (b == 127 || b == 8) { k.c = K_BS; return k; }
        if (b == 0x1f) { k.ctrl = true; k.c = '/'; return k; }
        if (b < 32) { k.ctrl = true; k.c = b + 96; return k; }
        k.c = K_CHAR;
        k.text = string(1, (char)b);
        int extra = b >= 0xF0 ? 3 : b >= 0xE0 ? 2 : b >= 0xC0 ? 1 : 0;
        for (int i = 0; i < extra; i++) {
            int c = t.readByte(20);
            if (c < 0) break;
            k.text += (char)c;
        }
        return k;
    }

    // ── строка ввода внизу ──
    bool prompt(const string& label, string& text, std::function<void(const string&)> onChange = nullptr,
                std::function<void(int)> onNav = nullptr, bool keepText = false) {
        promptOn = true;
        promptLabel = label;
        if (!keepText) promptText = text; else promptText = text;
        bool ok = false;
        while (true) {
            draw();
            Key k = readKey();
            if (k.c == K_NONE) continue;
            if (k.c == K_ENTER) { ok = true; break; }
            if (k.c == K_ESC) break;
            if (k.c == K_BS) {
                if (!promptText.empty()) promptText.erase(prevx(promptText, (int)promptText.size()));
                if (onChange) onChange(promptText);
            } else if (k.c == K_CHAR && !k.ctrl && !k.alt) {
                promptText += k.text;
                if (onChange) onChange(promptText);
            } else if (k.c == K_PASTE) {
                string s = normalize(k.text);
                size_t nl = s.find('\n');
                promptText += s.substr(0, nl);
                if (onChange) onChange(promptText);
            } else if (onNav && (k.c == K_DOWN || (k.ctrl && k.c == 'n'))) onNav(1);
            else if (onNav && (k.c == K_UP || (k.ctrl && k.c == 'p'))) onNav(-1);
        }
        promptOn = false;
        text = promptText;
        return ok;
    }

    // ── отрисовка ──
    void geom(const Rect& r) {
        px = r.x; py = r.y; pw = r.w; ph = r.h;
        textRows = std::max(1, ph - 1);
        int digits = 1;
        for (size_t n = d->L.size(); n >= 10; n /= 10) digits++;
        gut = cfg.lineNumbers ? std::max(digits, 3) + 2 : 0;
        textw = std::max(1, pw - gut);
    }
    string renderLine(int y) {
        static vector<unsigned char> h;
        const string& s = d->L[y];
        int stt = stateAt(y);
        scan(s, &h, stt);
        Pos a, b;
        bool hs = getSel(a, b) && a.y <= y && y <= b.y;
        int sa = 0, sb = 0;
        if (hs) { sa = (y == a.y) ? a.x : 0; sb = (y == b.y) ? b.x : (int)s.size() + 1; }
        string out;
        int emitted = 0;
        if (gut > 0) {
            string ns = std::to_string(y + 1);
            out = (y == cur.y ? gutCurStr : gutStr) + " " + string((size_t)std::max(0, gut - 2 - (int)ns.size()), ' ') + ns + " ";
            emitted = gut;
        }
        int lastSt = -1, lastSl = -1;
        auto style = [&](int st, int sl) {
            if (st == lastSt && sl == lastSl) return;
            out += "\x1b[0m";
            if (sl & 1) out += selStr;
            if (sl & 2) out += matchStr;
            out += hcol[st];
            lastSt = st; lastSl = sl;
        };
        int col = 0;
        for (int i = 0; i < (int)s.size();) {
            int len = nextx(s, i) - i;
            int w = s[i] == '\t' ? TAB - col % TAB : 1;
            int sl = (hs && i >= sa && i < sb) ? 1 : 0;
            if ((y == mA.y && i == mA.x) || (y == mB.y && i == mB.x)) sl |= 2;
            for (int k = 0; k < w; k++) {
                int c = col + k;
                if (c >= coloff && c < coloff + textw) {
                    style(h[i], sl);
                    if (s[i] == '\t') out += ' ';
                    else if ((unsigned char)s[i] < 32) out += '?';
                    else out.append(s, i, len);
                    emitted++;
                }
            }
            col += w;
            i += len;
            if (col >= coloff + textw) break;
        }
        if (hs && sb > (int)s.size() && col >= coloff && col < coloff + textw) { style(0, 1); out += ' '; emitted++; }
        out += "\x1b[0m";
        if (emitted < pw) out += string(pw - emitted, ' ');
        return out;
    }
    void scroll() {
        if (cur.y < rowoff) rowoff = cur.y;
        if (cur.y >= rowoff + textRows) rowoff = cur.y - textRows + 1;
        int c = dcol(d->L[cur.y], cur.x);
        if (c < coloff) coloff = c;
        if (c >= coloff + textw) coloff = c - textw + 1;
    }
    vector<string> renderPane(const Rect& r, bool active) {
        geom(r);
        scroll();
        if (active) computeMatch(); else mA = mB = {-1, -1};
        vector<string> out;
        for (int rr = 0; rr < textRows; rr++) {
            int y = rowoff + rr;
            out.push_back(y < (int)d->L.size() ? renderLine(y) : gutStr + "~\x1b[0m" + string(std::max(0, pw - 1), ' '));
        }
        string left = " " + (d->path.empty() ? string("[без имени]") : d->path) + (d->dirty ? " [+]" : "");
        string right = pw < 50 ? "Стр " + std::to_string(cur.y + 1) + " "
                               : "Стр " + std::to_string(cur.y + 1) + "/" + std::to_string(d->L.size()) + "  Кол " +
                                     std::to_string(dcol(d->L[cur.y], cur.x) + 1) + "  " + d->langName + "  " +
                                     (d->crlf ? "CRLF" : "LF") + " ";
        int padn = pw - ulen(left) - ulen(right);
        string sb = padn >= 1 ? left + string(padn, ' ') + right : ucut(left, pw);
        if (ulen(sb) < pw) sb += string(pw - ulen(sb), ' ');
        out.push_back((active ? stActive : stInactive) + sb + "\x1b[0m");
        return out;
    }
    string tabBar() {
        tabSpans.clear();
        tabSpanIdx.clear();
        vector<string> labels;
        for (int i = 0; i < (int)tabs.size(); i++) {
            Doc* dd = tabs[i].panes[tabs[i].active].doc.get();
            string nm = dd->path.empty() ? string("[без имени]") : baseName(dd->path);
            if (ulen(nm) > 20) nm = ucut(nm, 19) + "…";
            labels.push_back(" " + std::to_string(i + 1) + " " + nm + (dd->dirty ? " +" : "") + " ");
        }
        int start = 0, w = 0;
        for (int i = ti; i >= 0; i--) {
            w += ulen(labels[i]) + 1;
            if (w > cols) { start = i + 1; break; }
        }
        string out;
        int x = 0;
        for (int i = start; i < (int)tabs.size() && x < cols; i++) {
            string lab = labels[i];
            int l = ulen(lab);
            if (x + l > cols) { lab = ucut(lab, cols - x); l = ulen(lab); }
            out += (i == ti ? stActive : stInactive) + lab + "\x1b[0m";
            tabSpans.push_back({x + 1, x + l});
            tabSpanIdx.push_back(i);
            x += l;
            if (x < cols) { out += ' '; x++; }
        }
        if (x < cols) out += string(cols - x, ' ');
        return out;
    }
    void draw() {
        int R, C;
        t.size(R, C);
        string out = "\x1b[?25l";
        if (R != rows || C != cols || prev.empty()) {
            rows = R; cols = C;
            prev.assign(rows, "\x01");
            out += "\x1b[2J";
        }
        auto put = [&](int r, const string& row) {
            if (r < 0 || r >= rows || prev[r] == row) return;
            prev[r] = row;
            out += "\x1b[" + std::to_string(r + 1) + ";1H" + row + "\x1b[K";
        };
        bool bar = tabs.size() > 1;
        int top = bar ? 1 : 0;
        int contentH = std::max(3, rows - top - 1);
        if (bar) put(0, tabBar());
        Tab& tb = tabs[ti];
        int n = (int)tb.panes.size(), act = tb.active;
        rects.assign(n, Rect());
        if (tb.vsplit) {
            int avail = std::max(n, cols - (n - 1)), base = avail / n, extra = avail % n, x = 0;
            for (int i = 0; i < n; i++) {
                int w = base + (i < extra ? 1 : 0);
                rects[i].x = x; rects[i].y = top; rects[i].w = w; rects[i].h = contentH;
                x += w + 1;
            }
        } else {
            int base = contentH / n, extra = contentH % n, y = top;
            for (int i = 0; i < n; i++) {
                int h = std::max(3, base + (i < extra ? 1 : 0));
                rects[i].x = 0; rects[i].y = y; rects[i].w = cols; rects[i].h = h;
                y += h;
            }
        }
        vector<vector<string>> segs(n);
        segs[act] = renderPane(rects[act], true);  // активная панель — в «живом» состоянии
        View av = liveView();
        Doc* ad = d;
        for (int i = 0; i < n; i++) {
            if (i == act) continue;
            Pane& pn = tb.panes[i];
            setLive(pn.v, pn.doc.get());
            segs[i] = renderPane(rects[i], false);
            pn.v = liveView();
        }
        setLive(av, ad);
        geom(rects[act]);
        string sep = gutStr + "│\x1b[0m";
        for (int rr = 0; rr < contentH; rr++) {
            string row;
            if (tb.vsplit) {
                for (int i = 0; i < n; i++) {
                    if (i) row += sep;
                    row += rr < (int)segs[i].size() ? segs[i][rr] : string(rects[i].w, ' ');
                }
            } else {
                for (int i = 0; i < n; i++)
                    if (rr >= rects[i].y - top && rr < rects[i].y - top + rects[i].h) {
                        int lr = rr - (rects[i].y - top);
                        row = lr < (int)segs[i].size() ? segs[i][lr] : string(cols, ' ');
                    }
            }
            put(top + rr, row);
        }
        string m;
        if (promptOn) m = "\x1b[1m" + promptLabel + "\x1b[0m" + promptText;
        else if (!msg.empty()) m = ucut(msg, cols);
        else m = gutStr + "^S сохр  ^Q выход  ^P файлы/команды  ^F поиск  ^R замена  ^T вкладка  ^\\ сплит  ^W закрыть\x1b[0m";
        put(rows - 1, m);
        int cy, cx;
        if (promptOn) { cy = rows; cx = ulen(promptLabel) + ulen(promptText) + 1; }
        else { cy = py + (cur.y - rowoff) + 1; cx = px + gut + dcol(d->L[cur.y], cur.x) - coloff + 1; }
        out += "\x1b[" + std::to_string(std::max(1, cy)) + ";" + std::to_string(std::max(1, std::min(cx, cols))) + "H\x1b[?25h";
        t.write(out);
    }

    // ── мышь ──
    void mouse(const Key& k) {
        bool wheel = k.mb == 64 || k.mb == 65;
        bool press = !wheel && !k.release && (k.mb & 3) == 0 && !(k.mb & 32);
        int mx = k.mx - 1, my = k.my - 1;
        if (tabs.size() > 1 && my == 0) {
            if (press)
                for (size_t i = 0; i < tabSpans.size(); i++)
                    if (k.mx >= tabSpans[i].first && k.mx <= tabSpans[i].second) { goTab(tabSpanIdx[i]); break; }
            return;
        }
        if (press || wheel) {
            for (int i = 0; i < (int)rects.size(); i++) {
                const Rect& r = rects[i];
                if (mx >= r.x && mx < r.x + r.w && my >= r.y && my < r.y + r.h) {
                    if (i != tabs[ti].active) { activate(ti, i); geom(rects[i]); }
                    break;
                }
            }
        }
        if (wheel) {
            int dl = k.mb == 64 ? -3 : 3;
            rowoff = std::max(0, std::min(rowoff + dl, (int)d->L.size() - 1));
            if (cur.y < rowoff) vmove(rowoff - cur.y, false);
            else if (cur.y >= rowoff + textRows) vmove(rowoff + textRows - 1 - cur.y, false);
            return;
        }
        int r = my - py;
        if (r < 0 || r >= textRows) { if (k.release) dragging = false; return; }
        int y = std::min(rowoff + r, (int)d->L.size() - 1);
        int c = std::max(0, mx - px - gut + coloff);
        Pos pp{y, col2x(d->L[y], c)};
        if ((k.mb & 3) != 0 && !(k.mb & 32)) return;  // только левая кнопка
        if (k.release) { dragging = false; return; }
        if (k.mb & 32) { if (dragging) { cur = pp; want = dcol(d->L[y], pp.x); } return; }
        dragging = true;
        sel = true;
        anc = pp;
        cur = pp;
        want = dcol(d->L[y], pp.x);
        d->noMerge = true;
    }

    // ── клавиши ──
    static string keySpec(const Key& k) {
        string sp;
        if (k.ctrl) sp += "ctrl+";
        if (k.alt) sp += "alt+";
        if (k.shift) sp += "shift+";
        switch (k.c) {
            case K_UP: return sp + "up";
            case K_DOWN: return sp + "down";
            case K_LEFT: return sp + "left";
            case K_RIGHT: return sp + "right";
            case K_HOME: return sp + "home";
            case K_END: return sp + "end";
            case K_PGUP: return sp + "pgup";
            case K_PGDN: return sp + "pgdn";
            case K_DEL: return sp + "del";
            case K_TAB: return sp + "tab";
            case K_ENTER: return sp + "enter";
            case K_BS: return sp + "bs";
            case K_ESC: return sp + "esc";
            case K_CHAR: {
                string x = k.text;
                if (x.size() == 1) x[0] = (char)tolower((unsigned char)x[0]);
                if (x == " ") x = "space";
                return sp + x;
            }
            default:
                if (k.c >= K_F1 && k.c < K_F1 + 12) return sp + "f" + std::to_string(k.c - K_F1 + 1);
                if (k.c == '/') return sp + "slash";
                if (k.c == 124) return sp + "backslash";
                if (k.c == 125) return sp + "rbracket";
                if (k.c >= 32 && k.c < 127) return sp + string(1, (char)k.c);
                return sp + "?";
        }
    }
    void handle(const Key& k) {
        if (k.c == K_MOUSE) { mouse(k); return; }
        if (k.c == K_PASTE) { insertText(normalize(k.text)); d->noMerge = true; return; }
        auto it = binds.find(keySpec(k));
        string action = it != binds.end() ? it->second : string();
        if (action != "quit") quitArm = false;
        if (action != "close" && action != "close_tab") closeArm = false;
        if (!action.empty()) { runAction(action); return; }
        if (k.ctrl && k.c >= 32 && k.c < 1000) return;  // ctrl+буква без привязки
        bool ext = k.shift;
        switch (k.c) {
            case K_ESC: sel = false; return;
            case K_ENTER: enter(); return;
            case K_TAB: tab(k.shift); return;
            case K_BS: backspace(); return;
            case K_DEL: del(); return;
            case K_LEFT: {
                Pos a, b;
                if (!ext && !k.ctrl && getSel(a, b)) { moveTo(a, false); return; }
                if (k.ctrl) { wordLeft(ext); return; }
                Pos q = cur;
                if (q.x > 0) q.x = prevx(d->L[q.y], q.x);
                else if (q.y > 0) q = {q.y - 1, (int)d->L[q.y - 1].size()};
                moveTo(q, ext);
                return;
            }
            case K_RIGHT: {
                Pos a, b;
                if (!ext && !k.ctrl && getSel(a, b)) { moveTo(b, false); return; }
                if (k.ctrl) { wordRight(ext); return; }
                Pos q = cur;
                if (q.x < (int)d->L[q.y].size()) q.x = nextx(d->L[q.y], q.x);
                else if (q.y + 1 < (int)d->L.size()) q = {q.y + 1, 0};
                moveTo(q, ext);
                return;
            }
            case K_UP: vmove(-1, ext); return;
            case K_DOWN: vmove(1, ext); return;
            case K_PGUP: vmove(-textRows, ext); rowoff = std::max(0, rowoff - textRows); return;
            case K_PGDN: vmove(textRows, ext); return;
            case K_HOME:
                if (k.ctrl) moveTo({0, 0}, ext);
                else smartHome(ext);
                return;
            case K_END:
                if (k.ctrl) moveTo({(int)d->L.size() - 1, (int)d->L.back().size()}, ext);
                else moveTo({cur.y, (int)d->L[cur.y].size()}, ext);
                return;
            case K_CHAR:
                if (k.alt || k.text.empty()) return;
                typeChar(k.text);
                return;
        }
    }

    void run() {
        live = true;
        applyMouse();
        bool need = true;
        while (!quit) {
            if (!msg.empty() && std::chrono::steady_clock::now() > msgUntil) { msg.clear(); need = true; }
            int R, C;
            t.size(R, C);
            if (R != rows || C != cols) need = true;
            if (need) { draw(); need = false; }
            Key k = readKey();
            if (k.c == K_NONE) continue;
            need = true;
            handle(k);
        }
    }
};

int main(int argc, char** argv) {
    if (argc > 1 && (string(argv[1]) == "-h" || string(argv[1]) == "--help")) {
        puts("nib — терминальный редактор для кода\nИспользование: nib [файл ...]\nКонфиг:");
        puts(Editor::cfgPath().c_str());
        return 0;
    }
    Term t;
    Editor ed(t);
    for (int i = 1; i < argc; i++) {
        if (i == 1) ed.load(argv[i]);
        else ed.openInTab(argv[i]);
    }
    if (argc > 2) ed.goTab(0);
    t.enter(ed.cfg.mouse);
    ed.run();
    t.leave();
    return 0;
}
