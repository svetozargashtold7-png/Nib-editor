# nib

Быстрый терминальный редактор для кода: управление как в micro (без режимов), скорость как у vim.
Один файл, C++17, без зависимостей. Нужен компилятор с `<filesystem>` (GCC 9+, Clang 9+, MSVC 2017+).

## Сборка
- Linux / macOS: `make && sudo make install`
- Termux: `pkg install clang make && make && cp nib $PREFIX/bin/`
- Windows (Windows Terminal): `cmake -B build && cmake --build build --config Release`

Запуск: `nib файл1 файл2 ...` (каждый файл — своя вкладка).

## Клавиши (все переназначаются в конфиге)
| Действие | Клавиши |
|---|---|
| Сохранить / выйти | Ctrl+S / Ctrl+Q |
| Отмена / повтор | Ctrl+Z / Ctrl+Y |
| Копировать / вырезать / вставить | Ctrl+C / Ctrl+X / Ctrl+V (без выделения — вся строка) |
| Выделить всё | Ctrl+A |
| **Быстрое открытие файла (fuzzy)** | **Ctrl+P** |
| **Палитра команд** (все действия) | **F1**, Alt+P или Ctrl+P, затем `>` |
| Поиск, дальше / назад | Ctrl+F, Ctrl+N / Ctrl+B (или F3 / Shift+F3) |
| Замена (y/n/a, один шаг undo) | Ctrl+R |
| Поиск по файлам проекта | Ctrl+E или Alt+F |
| Перейти к строке[:колонка] | Ctrl+G |
| Открыть файл в этой панели | Ctrl+O |
| Комментарий строк | Ctrl+/ |
| Дублировать / удалить строку | Ctrl+D / Ctrl+K |
| Переместить строки | Alt+↑ / Alt+↓ |
| Отступ / убрать отступ | Tab / Shift+Tab (работает на выделении) |
| Слово назад/вперёд | Ctrl+←/→; удалить слово — Alt+Backspace |
| **Новая вкладка / закрыть панель или вкладку** | **Ctrl+T / Ctrl+W** |
| **Сплит: вертикальный / горизонтальный** | **Ctrl+\ / Ctrl+]** |
| Следующая панель | F6 или Alt+W (или клик мышью) |
| Переключить вкладку | Ctrl+PgUp/PgDn, Alt+←/→, Alt+1…9, клик по вкладке |

В Termux, если нужных клавиш нет, всё доступно через палитру: F1 (или Ctrl+P, затем `>`) и начало названия команды.

Вкладка может содержать до 4 панелей. Панели одного файла делят один буфер: правка видна во всех сразу.

## Конфиг
`~/.config/nib/config` (Windows: `%APPDATA%\nib\config`, переопределить: `NIB_CONFIG`).
Открыть и создать шаблон: палитра → «Открыть конфиг». После сохранения этого файла в nib настройки применяются сразу.

```
tab_size = 4
expand_tab = true
line_numbers = true
auto_pair = true
auto_indent = true
highlight = true
mouse = true
theme = dark            # dark | light
color.keyword = 176     # 0-255, ключи: keyword string comment number function gutter gutter_cur
                        # selection match status_fg status_bg status_inactive_fg status_inactive_bg
bind.ctrl+d = duplicate_line
bind.ctrl+q = none      # отключить клавишу
```
Список действий для `bind.*` — в шаблоне конфига и в палитре.
Клавиши: `ctrl+`, `alt+`, `shift+` и имя (`a-z 0-9 up down left right home end pgup pgdn del tab enter bs esc f1-f12 slash backslash rbracket`).

## Что есть
Автозакрытие скобок/кавычек (и обёртка выделения), парная скобка, автоотступ, подсветка (C-семейство, Python, shell,
JSON, CSS, HTML/XML/Markdown, конфиги) с многострочными комментариями и строками, мышь и колесо, bracketed paste,
буфер обмена через OSC 52 (и `termux-clipboard-*` в Termux), CRLF/LF, UTF-8. Файлы на 1 млн строк открываются за доли секунды.

## Ограничения
Широкие символы (CJK, эмодзи) сбивают выравнивание. Файл читается в память целиком.
Протестировано на Linux; Termux, macOS и Windows — по возможности проверьте и сообщите о проблемах.

## Дальше
tree-sitter, LSP (автодополнение, переход к определению), плагины.
